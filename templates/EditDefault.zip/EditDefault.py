import boto3
import cfnresponse
import json
import logging
import os


def handler(event, context):
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    responseData = {}
    responseStatus = cfnresponse.FAILED
    logger.info('Received event: {}'.format(json.dumps(event)))
    if event["RequestType"] == "Delete":
        responseStatus = cfnresponse.SUCCESS
        cfnresponse.send(event, context, responseStatus, responseData)
    if event["RequestType"] == "Create":
        try:
            print "Retrieve VPC and Subnet ID"
            VpcId = os.environ["InputVpcId"]
            PubSubnetId = os.environ["InputSubnetId"]
            DestCidr = os.environ["InputDestCidr"]
        except Exception as e:
            logger.info('VPC and/or subnet id retrival failure: {}'.format(e))
        try:
            ec2 = boto3.resource('ec2')
            vpc = ec2.Vpc(VpcId)
        except Exception as e:
            logger.info('boto3.resource failure: {}'.format(e))
        try:
            rt = list(vpc.route_tables.all())
            for rt in rt:
                if len(rt.associations_attribute) != 0:
                    if rt.associations_attribute[0]['Main'] == True:
                        rtId = rt.id
        except Exception as e:
            logger.info('ec2.vpc.route_tables.all failure: {}'. format(e))
        try:
            route_table = ec2.RouteTable(rtId)
        except Exception as e:
            logger.info('boto3.resource failure: {}'.format(e))
        try:
            igwIterator = list(vpc.internet_gateways.all())
            if len(igwIterator) != 0:
                for igw in igwIterator:
                    igwId = igw.id
            route_table_association = route_table.associate_with_subnet(SubnetId=PubSubnetId)
            route = route_table.create_route(
                DestinationCidrBlock=DestCidr,
                GatewayId=igwId
            )
        except Exception as e:
            logger.info('failed to edit route table failure: {}'. format(e))
    responseData['DefaultRtId'] = rtId
    responseData['IgwId'] = igwId
    responseStatus = cfnresponse.SUCCESS
    print responseData
    cfnresponse.send(event, context, responseStatus, responseData)
